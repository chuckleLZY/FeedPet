namespace SyaApi.Constants
{
    public static class Limit
    {
        public const int UsernameLength = 31;
    }
}
