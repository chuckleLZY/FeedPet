namespace SyaApi.Constants
{
    public static class Error
    {
        public const string NotFindString = "Not Find @#$%^&*()12=3_4+-56qwertyuio";
        public const double NotFindDouble = -2343842.1234;
    }
}