namespace SyaApi.Constants
{
    public static class Role
    {
        public const int Superuser = 0;
        public const int Student = 1;
        public const int Provider = 2;
        public const int Admin = 3;
    }
}
