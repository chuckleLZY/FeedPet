namespace SyaApi.Responses
{
    public class UserResponse
    {
        public int user_id { get; set; }
        public int user_role { get; set; }
        public string user_name { get; set; }
        public bool gender { get; set; }
        public string avatar { get; set; }
        public string email { get; set; }
        public string tel { get; set; }
        public string bank { get; set; }
    }
}
